
if(!requireNamespace("devtools"))
  install.packages("devtools")

library(devtools)

install_github("gluck4668/LXwgcna")

library(LXwgcna)

??LXwgcan

#-----------------------
data(meta_data_example)
data(experiment_info_example)

#-----------------------
rm(list=ls())

data_file <- "meta_data_example.xlsx"
expriment_info <- "experiment_info_example.xlsx"
key_phenotype <- "body_weight"

LXwgcna (data_file,expriment_info,key_phenotype)
